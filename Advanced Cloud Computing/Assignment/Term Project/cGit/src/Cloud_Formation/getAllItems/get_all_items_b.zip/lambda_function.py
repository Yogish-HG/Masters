import boto3

def lambda_handler(event, context):
    # Specify the DynamoDB table name
    table_name = 'termProjectItemsTable'

    # Create a DynamoDB resource
    dynamodb = boto3.resource('dynamodb')

    # Get the DynamoDB table
    table = dynamodb.Table(table_name)

    try:
        # Scan the table to retrieve all items
        response = table.scan()

        # Extract the items from the response
        items = response['Items']

        # Return the items
        return {
            'statusCode': 200,
            'body': items
        }

    except Exception as e:
        # Handle any exceptions
        print(f"Error: {e}")
        return {
            'statusCode': 500,
            'body': f'Error: {e}'
        }
